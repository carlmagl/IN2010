# IN2010
Algoritmer og datastrukturer - Oblig1

hvordan	programmet	skal	kompileres
- Programmet kompileres med aa skrive Javac * .java, (uten mellomrom).

hvilken	fil	som	inneholder	main-metoden
- Filen som inneholder main metoden er BSTtest

hvilke	antakelser	du	har	gjort	når	du løste	oppgaven
- Jeg antar at ingen noder kan være like

hvilke	saregenheter	din	implementasjon	inneholder
- Litt usikker paa hva som skal skrives her, gjerne feedback paa hva det kunne vart

hva	som	ikke	fungerer	slik	det	skal
- Remove fjerner ikke helt riktig, ellers tror jeg alt fungerer

hva	du	helst	vil	ha	tilbakemelding	fra	din	retter	om
- Alle feil eller forbedringer som kunne vart gjort og hvordan remove burde vrt gjort
